Put your two pictures in this folder and rename them:
photo1.jpg
photo2.jpg

Optional music:
If you have an audio file you are allowed to use, name it song.mp3 and put it here.
The website starts it after Arnav taps "Tap to open", because browsers commonly block
sound autoplay before a user interaction.
